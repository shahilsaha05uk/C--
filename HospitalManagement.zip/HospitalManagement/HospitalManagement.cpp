#include "Base.h"
using namespace std;

int main()
{
	Base* b = new Base();

}